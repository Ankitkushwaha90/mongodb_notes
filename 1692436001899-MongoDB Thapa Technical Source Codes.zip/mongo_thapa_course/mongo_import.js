//* MONGOIMPORT
// Now I will show How to import data from json file

//? mongoimport E:\\mongo\products.json -d shop -c products

//? mongoimport E:\\mongo\products.json -d shop -c products --jsonArray
