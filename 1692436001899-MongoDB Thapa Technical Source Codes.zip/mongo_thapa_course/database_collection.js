//TODO We will work with multiple data and it will be fun and it is going to be the best video over the internet for sure

//? 1:  Creating / Deleting Databases
// show dbs
// use thapaProducts
// db.dropDatabase()

//? 2:  Creating / Deleting Databases and Collections
// db.createCollection('test')
// show collections
// db.test.drop() // where the test is the collection name

💖 Thank You So Much For Choosing My Video 💖

Hi everyone,

I'm absolutely thrilled – we're almost at 600K subscribers for our MongoDB course! This course was a true labor of love, and it's been amazing to see how it's helping you all.

If you've enjoyed what we're doing and want to be part of our journey, hitting that Subscribe button would mean the world to me. Let's keep growing and learning together!
Here is the link: https://www.youtube.com/thapatechnical

With gratitude,
Thapa Technical 